function toggleMenu() {
    let nav = document.getElementById("nav-links");
    nav.classList.toggle("show");
}

function showSection(sectionId) {
    const sectionToScroll = document.getElementById(sectionId);
    if (sectionToScroll) {
        sectionToScroll.scrollIntoView({ behavior: "smooth" });
    }
}

document.addEventListener("DOMContentLoaded", () => {
    showSection("home"); 
    
    const resumeBtn = document.getElementById("resume-btn");
    if (resumeBtn) {
        resumeBtn.addEventListener("click", function () {
            window.open(
                "https://drive.google.com/file/d/1C_Zh7ijyeDC1IO4gmQb739CfTV7q0qmN/view?usp=drive_link",
                "_blank"
            );
        });
    }
    const form = document.getElementById('contact-form');
    
    form.addEventListener('submit', function(event) {
        event.preventDefault(); 

        const formData = new FormData(form);
        fetch(form.action, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())  
        .then(data => {
            if (data.success) {
                
                document.getElementById('successMessage').style.display = 'block';
                form.reset(); 
            } else {
                
                alert('Sorry, something went wrong. Please try again.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error submitting the form. Please try again.');
        });
    });

    document.querySelectorAll(".nav-links a, .btn").forEach((link) => {
        link.addEventListener("click", function (event) {
            event.preventDefault();
            const targetId = this.getAttribute("href").substring(1); 

            if (targetId === "certifications") {
                document.getElementById("certifications").style.display = "block";
            }

            showSection(targetId);
        });
    });
});